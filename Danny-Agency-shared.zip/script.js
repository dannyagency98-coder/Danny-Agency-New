
// about.js
document.addEventListener("DOMContentLoaded", function() {
            const logo = document.querySelector('.logo');

            if (logo) {
                logo.onclick = function() {
                    window.location.href = "/";
                };
            }
        });
        function drawCraterWithText() {
    const height = 20; // Height of the crater
    const width = 40; // Width of the crater
    const text = "MADE BY DANNY AGENCY";

    const redDash = '\x1b[31m---\x1b[0m'; // Red dashes
    const blackSpace = '\x1b[40m   \x1b[0m'; // Black background space

    let output = '';

    for (let i = 0; i < height; i++) {
        for (let j = 0; j < width; j++) {
            // Calculate the starting position of the text
            const textStartRow = Math.floor((height - 1) / 2);
            const textStartCol = Math.floor((width - text.length) / 2);

            // Check if current position is within the bounds of the text
            if (i === textStartRow && j >= textStartCol && j < textStartCol + text.length) {
                // Extract the character to display
                const charIndex = j - textStartCol;
                const char = text[charIndex];
                output += `\x1b[40m${char}\x1b[0m`; // Display character with black background
            } else {
                output += redDash;
            }
        }
        output += '\n';
    }

    console.log(output);
}

drawCraterWithText();

document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };

  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});

window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });

// contact.js
document.addEventListener("DOMContentLoaded", function() {
            const logo = document.querySelector('.logo');

            if (logo) {
                logo.onclick = function() {
                    window.location.href = "/";
                };
            }
        });
        function disableFirstOption() {
    const selectElement = document.getElementById('budget');
    const firstOption = selectElement.options[0];

    // Disable the first option if any other option is selected
    if (selectElement.selectedIndex !== 0) {
        firstOption.disabled = true;
    }
}

document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };

  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});

window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });

// faqs.js
const items = document.querySelectorAll(".accordion button");function toggleAccordion() {  const itemToggle = this.getAttribute('aria-expanded');    for (i = 0; i < items.length; i++) {    items[i].setAttribute('aria-expanded', 'false');  }    if (itemToggle == 'false') {    this.setAttribute('aria-expanded', 'true');  }}items.forEach(item => item.addEventListener('click', toggleAccordion));document.addEventListener("DOMContentLoaded", function() {            const logo = document.querySelector('.logo');            if (logo) {                logo.onclick = function() {                    window.location.href = "/";                };            }        });

document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };

  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});

window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });

// index.js
document.addEventListener('DOMContentLoaded', function() {
 document.addEventListener('DOMContentLoaded', function() {
            const modelViewer = document.getElementById('model-viewer');

            // Disable context menu
            modelViewer.addEventListener('contextmenu', function(event) {
                event.preventDefault();
            });

            // Prevent default behavior on right mouse button down
            modelViewer.addEventListener('mousedown', function(event) {
                if (event.button === 2) { // Right mouse button
                    event.preventDefault();
                }
            });

            // Prevent panning and zooming
            modelViewer.addEventListener('mousemove', function(event) {
                if (event.buttons === 2) { // Right mouse button
                    event.preventDefault(); // Prevent panning when right-click dragging
                }
            });

            modelViewer.addEventListener('touchstart', function(event) {
                if (event.touches.length > 1) { // Multiple touch points
                    event.preventDefault(); // Prevent zoom and pan on touch
                }
            });

            modelViewer.addEventListener('touchmove', function(event) {
                if (event.touches.length > 1) { // Multiple touch points
                    event.preventDefault(); // Prevent zoom and pan on touch
                }
            });

            // Custom rotation handling
            document.addEventListener('mousemove', function(e) {
                const x = e.clientX / window.innerWidth - 0.5; // Normalize to range [-0.5, 0.5]
                const y = e.clientY / window.innerHeight - 0.5; // Normalize to range [-0.5, 0.5]
                const deltaTheta = x * Math.PI; // Rotation angle around Y-axis
                const deltaPhi = y * Math.PI / 2; // Rotation angle around X-axis

                modelViewer.cameraTarget = `0m 0m 0m`; // Reset camera target to center
                modelViewer.cameraOrbit = `${deltaTheta}rad ${deltaPhi}rad 2m`; // Set camera orbit
            });

            // Reset rotation on mouse leave
            document.addEventListener('mouseleave', function() {
                modelViewer.cameraTarget = `0m 0m 0m`;
                modelViewer.cameraOrbit = `0rad 0rad 2m`;
            });
        });

        window.addEventListener('load', function() {
            const modelViewer = document.getElementById('model-viewer');
            const preloader = document.getElementById('model-preloader');
            
            modelViewer.addEventListener('load', () => {
                preloader.style.display = 'none';
            });
        });
    // Logo click event to navigate
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.onclick = function() {
            window.location.href = "/";
        };
    }
});
 window.addEventListener('load', function() {
            const textElement = document.getElementById('fadeInText');
            const originalHTML = textElement.innerHTML;
            textElement.innerHTML = ''; // Clear the existing content

            let delay = 0;

            // Function to process each node recursively
            function processNode(node) {
                if (node.nodeType === Node.TEXT_NODE) {
                    // Wrap each word in a span
                    const words = node.textContent.split(/(\s+)/);
                    words.forEach(word => {
                        if (word.trim() !== '') {
                            const span = document.createElement('span');
                            span.textContent = word;
                            span.className = 'fade-in';
                            span.style.transitionDelay = `${delay * 0.5}s`;
                            textElement.appendChild(span);
                            delay++;
                        } else {
                            textElement.appendChild(document.createTextNode(word));
                        }
                    });
                } else if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'BR') {
                    // Append BR elements directly
                    textElement.appendChild(node.cloneNode());
                } else {
                    // Process other element nodes recursively
                    const wrapper = document.createElement(node.tagName);
                    textElement.appendChild(wrapper);
                    Array.from(node.childNodes).forEach(processNode);
                }
            }

            // Create a temporary container to parse the original HTML
            const tempContainer = document.createElement('div');
            tempContainer.innerHTML = originalHTML;
            Array.from(tempContainer.childNodes).forEach(processNode);

            // Add a class to each span after a delay
            setTimeout(function() {
                const spans = textElement.querySelectorAll('span.fade-in');
                spans.forEach(span => {
                    span.style.opacity = '1';
                });
            }, 2000);
        });
        const modelViewer = document.getElementById('model-viewer');
    const preloader = document.getElementById('model-preloader');
    
    modelViewer.addEventListener('load', () => {
        preloader.style.display = 'none';
    });

document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };


  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});

document.getElementById('model-viewer').addEventListener('contextmenu', function(event) {
            event.preventDefault();
        });
        
        window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });

// login.js
document.getElementById('toggleButton').addEventListener('click', function(event) {
            event.preventDefault();  // Prevent form submission
            const passwordField = document.querySelector('.password');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                this.innerHTML = `<i class="bi bi-eye-slash-fill"></i>`;
            } else {
                passwordField.type = 'password';
                this.innerHTML = `<i class="bi bi-eye-fill"></i>`;
            }
        });

document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };

  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});

window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });

// portfolio.js
document.addEventListener("DOMContentLoaded", function() {
            const logo = document.querySelector('.logo');

            if (logo) {
                logo.onclick = function() {
                    window.location.href = "/";
                };
            }
        });

                                document.addEventListener('DOMContentLoaded', function() {
  const checkbox = document.getElementById('click');
  const links = document.querySelectorAll('nav ul li a');

  const applyMobileStyles = () => {
    if (window.innerWidth <= 920) {
      // Apply fade-in and slide-in effect for mobile
      checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
          links.forEach((link, index) => {
            link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
            link.style.transform = 'translateX(0)'; // Slide in effect
            link.style.opacity = 1; // Fade in effect
          });
        } else {
          // Reset state when checkbox is unchecked
          links.forEach(link => {
            link.style.transition = 'none';
            link.style.transform = 'translateX(-100%)'; // Slide out effect
            link.style.opacity = 0; // Fade out effect
          });
        }
      });
    } else {
      // Ensure links are fully visible and positioned correctly for desktop
      links.forEach(link => {
        link.style.transition = 'none';
        link.style.transform = 'translateX(0)'; // Positioned correctly
        link.style.opacity = 1; // Full opacity
      });
    }
  };

  // Check on load and resize
  applyMobileStyles();
  window.addEventListener('resize', applyMobileStyles);
});


window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelector('.preloader').style.display = 'none';
      document.body.style.overflow = 'auto';
    }, 2000);
  });


document.addEventListener('DOMContentLoaded', function() {
  const imageInput = document.getElementById('imageInput');
  if (!imageInput) return;
  imageInput.addEventListener('change', function(event) {
    const files = event.target.files;
    const previewContainer = document.getElementById('previewContainer');
    previewContainer.innerHTML = '';
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = function(e) {
        const img = document.createElement('img');
        img.src = e.target.result;
        img.style.width = '150px';
        img.style.height = '150px';
        img.style.objectFit = 'cover';
        img.style.borderRadius = '10px';
        img.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
        previewContainer.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  });
});
